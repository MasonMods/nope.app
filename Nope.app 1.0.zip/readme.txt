Welcome to Nope.exe.

This was created by MasonMods on Github. 

This targets the Impero Client(s) installed on student macbooks used by teachers to remotely watch what the students are doing on their computers. 

This works for mac

Works after restart. 


HOW TO 
------------
1. Put the ZIP file on your student macbook
2. Extract the nope.app
3. Run the nope.app
4. delete it from your computer so they dont notice
5. Done

THIS DOES NOT WORK ON PC